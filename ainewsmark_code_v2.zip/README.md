# AINEWSMARK MVP Repo Files
Upload into your repo root.
